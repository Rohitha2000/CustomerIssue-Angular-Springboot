import { Component, OnInit } from '@angular/core';
import { IssueDetail } from '../Model/IssueDetail.model';
import { HttpClientService } from '../service/http-client.service';
@Component({
  selector: 'app-issueraised',
  templateUrl: './issueraised.component.html',
  styleUrls: ['./issueraised.component.css']
})
export class IssueraisedComponent implements OnInit {
  public issueDetail: IssueDetail= new IssueDetail(0,"","","","","","");
  constructor(private httpClientService: HttpClientService) { }

  ngOnInit(): void {
this.issueDetail.custIssueId=this.httpClientService.getcustissueId();
this.issueDetail.issueReportDate= this.httpClientService.getrepDate();
this.issueDetail.custId= this.httpClientService.getcustId();
this.issueDetail.category= this.httpClientService.getCat();
this.issueDetail.description= this.httpClientService.getDes();
this.issueDetail.issueStatus= this.httpClientService.getStatus();
this.issueDetail.ccRepId= this.httpClientService.getccRep();

  }

}
