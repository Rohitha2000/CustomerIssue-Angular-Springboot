import { Component, OnInit } from '@angular/core';
import { IssueDetail } from '../Model/IssueDetail.model';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'customer-issue',
  templateUrl: './customerissue.component.html',
  styleUrls: ['./customerissue.component.css']
})
export class CustomerIssueComponent implements OnInit {

  public issueDetail: IssueDetail= new IssueDetail(0,"","","","","","");
gotid:number=0;
 
  constructor(private httpClientService: HttpClientService) { }

  ngOnInit(): void {
    this.gotid= this.httpClientService.getGettingId();
    console.log("this.gotid:  "+this.gotid);
    this.httpClientService.getIssuesForCustomerId(this.gotid).subscribe(data => {
      this.issueDetail = data;
      console.log('Issue: ' + data.custId);
    });
  }

}
