export class IssueDetail {
  constructor(
    public custIssueId: number,
    public issueReportDate: string,
    public custId: string,
    public category: string,
    public description: string,
    public issueStatus: string,
    public ccRepId: string,
  ) { }
}