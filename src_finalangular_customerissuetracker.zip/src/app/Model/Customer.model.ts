export class Customer {
    constructor(
        public  custId:string,
        public custName:string,
        public custAddress:string,
        public  custPhone:string,
        public loginId:string,
        public password:string
    ) { }
  }