import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IssueraisedComponent } from './issueraised.component';

describe('IssueraisedComponent', () => {
  let component: IssueraisedComponent;
  let fixture: ComponentFixture<IssueraisedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IssueraisedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IssueraisedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
