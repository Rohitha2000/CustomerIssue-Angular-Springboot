import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IssueDetail } from '../Model/IssueDetail.model';

@Injectable({
  providedIn: 'root'
})

export class HttpClientService {

  private custid:string="";
  
  setcustId(value: string)
  {
    console.log("set"+value);
    this.custid=value;
  }
  getcustId():string{
    console.log("get"+this.custid);
    return this.custid;
  }


private issueid:number=0;
setcustissueId(value:number)
{
  this.issueid=value;
}
getcustissueId():number{
  return this.issueid;
}

private repdate:string="";
setreportDate(value:string){
  this.repdate= value;
}
getreportDate():string{
  return this.repdate;
}

private category:string="";
 setCategory(value: string){
this.category= value;
}
getCategory():string{
  return this.category;
}



private description:string="";
 setDescription(value: string){
this.description= value;
}
getDescription():string{
  return this.description;
}


private status:string="";
setStatus(value:string){
  this.status= value;
}
getStatus():string{
  return this.status;
}

private ccrepid:string="";
setccRepId(value:string){
  this.ccrepid= value;
}
getccRepId():string{
  return this.ccrepid;
}

private value1=0;
private gotissueid:number=0;
setGettingId(value1:number){
  console.log("settingg "+ value1);
  this.gotissueid= value1;
}
getGettingId():number{
  console.log("gettingg  "+this.gotissueid);
  return this.gotissueid;
}





  constructor(private httpClient: HttpClient) {}

  /*   getEmployees()
  {
    console.log("test call");
    return this.httpClient.get<Employee[]>('http://localhost:8080/employees');
  }*/

  /* public deleteEmployee(employee:any) {
     return this.httpClient.delete<Employee>("http://localhost:8080/employees" + "/"+ employee.empId);
   }*/
  /*public createCustomer(customer:any){
     return this.httpClient.post<Customer>("http://localhost:8082/", customer);
  }*/
  public createIssueDetail(issuedetail: any) {
    return this.httpClient.post<IssueDetail>("http://localhost:8082/issuedetail", issuedetail);
  }

  public getIssueData(issuedetail: any) {
    return this.httpClient.get<IssueDetail>("http://localhost:8082/issuedetail" + "/" + issuedetail.issue_id, issuedetail);
  }

  public getIssuesForCustomerId(customerId: number) {
    return this.httpClient.get<IssueDetail>("http://localhost:8082/issuedetail"+"/"+customerId);
  }




  // public getIssueById(issueId: number) {
  //   return this.httpClient.get<IssueDetail>("http://localhost:8082/issuedetail"+"/"+issueId);
  // }
}