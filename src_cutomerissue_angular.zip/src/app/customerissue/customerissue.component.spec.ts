import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerIssueComponent } from './customerissue.component';

describe('CustomerIssueComponent', () => {
  let component: CustomerIssueComponent;
  let fixture: ComponentFixture<CustomerIssueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerIssueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerIssueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
