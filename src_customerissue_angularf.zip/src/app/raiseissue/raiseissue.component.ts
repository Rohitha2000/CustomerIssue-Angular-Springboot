import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IssueDetail } from '../Model/IssueDetail.model';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-raiseissue',
  templateUrl: './raiseissue.component.html',
  styleUrls: ['./raiseissue.component.css']
})
export class RaiseissueComponent implements OnInit {
  
  public issueDetail: IssueDetail= new IssueDetail(this.getRandomNumber(),"","","","",this.getstatus(),this.getCCRepId());
public getstatus():string{
  return "In Progress";
}
 public getRandomNumber():number{
    let random:number = Math.floor(Math.random() * (1000) + 1000);
    return random;
}
public getCCRepId():string{
  let ccrepid= "CCR"+ Math.floor(Math.random()*(100)+50);
  return ccrepid;
}
 
  constructor(private httpClientService: HttpClientService,  private route:ActivatedRoute,private router:Router) { 
  
   
  }

  ngOnInit(): void {
    this.issueDetail.custId= this.httpClientService.getcustId();
    
  }
 checking(form:any){
  if(form.invalid){
    return;
}
this.createIssueDetail();

 }
  createIssueDetail():void{
    console.log("issue id"+ this.issueDetail.custIssueId);
    this.httpClientService.createIssueDetail(this.issueDetail)
    .subscribe( data => {
      alert("issue raised successfully.");
    });
    console.log("issue id"+ this.issueDetail.custIssueId);
    this.httpClientService.setcustissueId(this.issueDetail.custIssueId);
    this.httpClientService.setreportDate(this.issueDetail.issueReportDate);
    this.httpClientService.setcustId(this.issueDetail.custId);
    this.httpClientService.setCategory(this.issueDetail.category);
    this.httpClientService.setDescription(this.issueDetail.description);
    this.httpClientService.setStatus(this.issueDetail.issueStatus);
    this.httpClientService.setccRepId(this.issueDetail.ccRepId);
   //this.router.navigate(['/issueraised']);
   this.gotToPage();
  }

  gotToPage() : void {
    // something
      setTimeout(() => this.router.navigate(['/issueraised']),2500); // 2500 is millisecond
  }

}
