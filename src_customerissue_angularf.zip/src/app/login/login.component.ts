import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  option:any;
  isSubmitted: boolean=false;
  constructor(private httpClientService: HttpClientService, private route:ActivatedRoute,private router:Router) { 
  
  }

  ngOnInit(): void {
  }
  submitForm(form: NgForm):any {
    this.isSubmitted = true;
    if(!form.valid) {
      return false;
    } else {
    alert(JSON.stringify(form.value.option))
    this.option= JSON.stringify(form.value.issueid);
    this.loginpage();
    }
  }
  addEquipment(form:any){
    console.log("option"+ form.value.option);
    console.log("option id"+ form.value.issueid);
    if(form.invalid){
        return;
    }
    
    else if(form.value.option == 'view' && form.value.issueid == 0)
    {
      alert("please enter id");
      return;
    }
   
 this.submitForm(form);
 if(form.value.option== 'raise')
 {
  this.router.navigate(['/raiseissue']);
 }
 else if( form.value.option == 'view')
 {
  this.router.navigate(['/customerissue']);
 }
    //If it is valid it will continue to here...
 }
  loginpage()
  {
    console.log(this.option);
    this.httpClientService.setGettingId(this.option);
  }


  

}

