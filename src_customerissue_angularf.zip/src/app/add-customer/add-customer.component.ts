
import { Component, OnInit } from '@angular/core';
import { Routes , ActivatedRoute, Router} from '@angular/router';
import { Customer } from '../Model/Customer.model';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styles: [`background-color: yellow;`]
})
export class AddCustomerComponent implements OnInit {
  public customer: Customer = new Customer("", "", "", "", "", "");
  http1: any;
  
 // public issueDetail:IssueDetail= new IssueDetail(0,"","","","","","");
 constructor(private httpClientService: HttpClientService, private route: ActivatedRoute, private router:Router) { 
  //httpClientService.setcustId(this.custid);

}

  ngOnInit(): void {
    }

  public  custid:any;
  
  checking1(form:any){
    if(form.invalid){
      return;
  }
  if(form.valid){
    this.createCustomer();
  this.router.navigate(['/login']);
      }
  
  }
  createCustomer() {
   
    console.log('Customer ID: ' + this.customer.custId);
    this.custid=  this.customer.custId;
    this.httpClientService.setcustId(this.custid);
    this.alertbox();
  
  }
  alertbox(){
    alert("Customer form submitted successfully!");
  }
 
  
}
