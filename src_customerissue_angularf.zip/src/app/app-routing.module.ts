import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { CustomerIssueComponent } from './customerissue/customerissue.component';
import { IssueraisedComponent } from './issueraised/issueraised.component';
import { LoginComponent } from './login/login.component';
import { RaiseissueComponent } from './raiseissue/raiseissue.component';

const routes: Routes = [
 { path:'customerform', component: AddCustomerComponent},
 {path:'login', component:LoginComponent},
 {path:'raiseissue', component:RaiseissueComponent}, 
 {path:'issueraised', component:IssueraisedComponent},
 //{ path: 'raiseissue',   redirectTo: '/issueraised', pathMatch: 'full' },
 {path:'customerissue', component:CustomerIssueComponent}
];
 /* { path:'addemployee', component: AddEmployeeComponent},
  { path:'updateemployee', component: UpdateEmployeeComponent},
];*/

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
