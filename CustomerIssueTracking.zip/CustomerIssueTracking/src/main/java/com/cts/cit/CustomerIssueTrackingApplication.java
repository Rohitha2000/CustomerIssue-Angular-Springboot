package com.cts.cit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerIssueTrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerIssueTrackingApplication.class, args);
	}

}
