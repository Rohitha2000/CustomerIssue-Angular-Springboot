
import { Component, OnInit } from '@angular/core';
import { Customer } from '../Model/Customer.model';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styles: [`background-color: yellow;`]
})
export class AddCustomerComponent implements OnInit {
  public customer: Customer = new Customer("", "", "", "", "", "");
  http1: any;
 // public issueDetail:IssueDetail= new IssueDetail(0,"","","","","","");

  ngOnInit(): void {
    }

  public  custid:any;
  

  createCustomer() {
   
    console.log('Customer ID: ' + this.customer.custId);
    this.custid=  this.customer.custId;
    this.httpClientService.setcustId(this.custid);
    this.alertbox();
  
  }
  alertbox(){
    alert("Customer form submitted successfully!");
  }
  constructor(private httpClientService: HttpClientService) { 
    //httpClientService.setcustId(this.custid);
 
}
  
}
