import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IssueDetail } from '../Model/IssueDetail.model';

@Injectable({
  providedIn: 'root'
})

export class HttpClientService {

  private data1:string="";
  
  setcustId(value: string)
  {
    console.log("set"+value);
    this.data1=value;
  }
  getcustId():string{
    console.log("get"+this.data1);
    return this.data1;
  }


private issueid:number=0;
setcustissueId(value:number)
{
  this.issueid=value;
}
getcustissueId():number{
  return this.issueid;
}

private repdate:string="";
setrepDate(value:string){
  this.repdate= value;
}
getrepDate():string{
  return this.repdate;
}

private cate:string="";
 setCat(value: string){
this.cate= value;
}
getCat():string{
  return this.cate;
}



private desc:string="";
 setDes(value: string){
this.desc= value;
}
getDes():string{
  return this.desc;
}


private status:string="";
setStatus(value:string){
  this.status= value;
}
getStatus():string{
  return this.status;
}

private ccrep:string="";
setccRep(value:string){
  this.ccrep= value;
}
getccRep():string{
  return this.ccrep;
}

private value1=0;
private gotid:number=0;
setGettingId(value1:number){
  console.log("settingg "+ value1);
  this.gotid= value1;
}
getGettingId():number{
  console.log("gettingg  "+this.gotid);
  return this.gotid;
}





  constructor(private httpClient: HttpClient) {}

  /*   getEmployees()
  {
    console.log("test call");
    return this.httpClient.get<Employee[]>('http://localhost:8080/employees');
  }*/

  /* public deleteEmployee(employee:any) {
     return this.httpClient.delete<Employee>("http://localhost:8080/employees" + "/"+ employee.empId);
   }*/
  /*public createCustomer(customer:any){
     return this.httpClient.post<Customer>("http://localhost:8082/", customer);
  }*/
  public createIssueDetail(issuedetail: any) {
    return this.httpClient.post<IssueDetail>("http://localhost:8082/issuedetail", issuedetail);
  }

  public getIssueData(issuedetail: any) {
    return this.httpClient.get<IssueDetail>("http://localhost:8082/issuedetail" + "/" + issuedetail.issue_id, issuedetail);
  }

  public getIssuesForCustomerId(customerId: number) {
    return this.httpClient.get<IssueDetail>("http://localhost:8082/issuedetail"+"/"+customerId);
  }




  // public getIssueById(issueId: number) {
  //   return this.httpClient.get<IssueDetail>("http://localhost:8082/issuedetail"+"/"+issueId);
  // }
}