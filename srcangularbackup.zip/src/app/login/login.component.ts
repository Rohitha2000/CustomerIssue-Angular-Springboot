import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  option:any;
  isSubmitted: boolean=false;
  constructor(private httpClientService: HttpClientService) { 
  
  }

  ngOnInit(): void {
  }
  submitForm(form: NgForm):any {
    this.isSubmitted = true;
    if(!form.valid) {
      return false;
    } else {
    alert(JSON.stringify(form.value.option))
    this.option= JSON.stringify(form.value.issueid);
    this.loginpage();
    }
  }

  loginpage()
  {
    console.log(this.option);
    this.httpClientService.setGettingId(this.option);
  }

}

